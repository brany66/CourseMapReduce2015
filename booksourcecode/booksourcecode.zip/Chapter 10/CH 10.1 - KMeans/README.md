#Chapter 10.1 KMeans算法
##输入文件
格式如下:<br/>
1,2,3,4,5<br/>
3,4,6,5,1<br/>
每行一个实例。
##运行
输入参数：<br>
k: 簇中心数<br/>
iteration num: 迭代数<br/>
input path: 输入路径<br/>
output path: 输出路径<br/>
<br/>打包成jar后，运行：<br/>
> hadoop jar KMeans.jar <k\> <iteration num\> <input path\> <output path\> 