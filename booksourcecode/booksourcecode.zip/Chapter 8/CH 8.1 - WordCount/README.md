#  Chapter8.1 WordCount 说明

##使用方法
将源码打包成jar包后，执行如下命令：
>$ bin/hadoop jar WordCount.jar <input path\> <output path\>

**注意** 此程序源码来自hadoop 1.0.4包 org.apache.hadoop.examples