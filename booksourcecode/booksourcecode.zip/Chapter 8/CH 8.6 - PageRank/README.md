#  Chapter8.6 PageRank说明

##目录结构
	data - 测试数据样例, 包含样例文档wiki_0.txt	
	src  - 源代码目录
	

##使用方法

对于程序打包生成的jar包PageRank.jar，执行如下命令

`$ bin/hadoop jar PageRank.jar <files input path\>  <file output path\>`

##输入

` <files input path\>` 含有多个文本文件的文档目录, 例如该目录下有WebDoc1、WebDoc2、WebDoc3…… 文件格式类似 `wiki_0.txt`

 